package ir.prismswap.tapsellplugin;

import android.app.Activity;
import android.widget.FrameLayout;

import org.apache.cordova.CordovaPlugin;
import org.apache.cordova.CallbackContext;
import org.apache.cordova.PluginResult;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import ir.tapsell.mediation.Tapsell;
import ir.tapsell.mediation.ad.request.RequestResultListener;
import ir.tapsell.mediation.ad.request.BannerSize;
import ir.tapsell.mediation.ad.AdStateListener;
import ir.tapsell.mediation.ad.AdShowCompletionState;
import ir.tapsell.mediation.ad.views.banner.BannerContainer;

import java.util.HashMap;
import java.util.Map;

/**
 * پلاگین سفارشی Prism Swap برای Tapsell Mediation.
 * جایگزین tapsell-v3-cordova-plugin (که طبق اعلام پشتیبانی تپسل دیگه
 * نگهداری نمیشه و به SDK قدیمی ir.tapsell.sdk.* وصل میشه، نه Mediation).
 *
 * مستندات رسمی: https://docs.tapsell.ir/mediation/android/
 */
public class TapsellMediationPlugin extends CordovaPlugin {

    // بنر یه View بومیه، نه چیزی که مثل تبلیغ تمام‌صفحه فقط با adId کار کنه؛
    // پس باید یه BannerContainer رو نگه داریم و به ریشه‌ی صفحه اضافه کنیم.
    private BannerContainer bannerContainer;

    @Override
    public boolean execute(String action, JSONArray args, CallbackContext callbackContext) throws JSONException {
        final Activity activity = cordova.getActivity();

        switch (action) {

            case "requestInterstitial": {
                String zoneId = args.getString(0);
                Tapsell.requestInterstitialAd(zoneId, new RequestResultListener() {
                    @Override
                    public void onSuccess(String adId) {
                        callbackContext.success(adId);
                    }
                    @Override
                    public void onFailure() {
                        callbackContext.error("NO_FILL");
                    }
                });
                return true;
            }

            case "showInterstitial": {
                final String adId = args.getString(0);
                activity.runOnUiThread(() -> Tapsell.showInterstitialAd(adId, activity, new AdStateListener.Interstitial() {
                    @Override public void onAdImpression() { /* فقط لاگ سمت تپسل، اقدامی لازم نیست */ }
                    @Override public void onAdClicked() { /* فقط لاگ سمت تپسل، اقدامی لازم نیست */ }
                    @Override
                    public void onAdClosed(AdShowCompletionState completionState) {
                        callbackContext.success(completionState.name());
                    }
                    @Override
                    public void onAdFailed(String message) {
                        callbackContext.error(message == null ? "SHOW_FAILED" : message);
                    }
                }));
                return true;
            }

            case "requestRewarded": {
                String zoneId = args.getString(0);
                Tapsell.requestRewardedAd(zoneId, new RequestResultListener() {
                    @Override
                    public void onSuccess(String adId) {
                        callbackContext.success(adId);
                    }
                    @Override
                    public void onFailure() {
                        callbackContext.error("NO_FILL");
                    }
                });
                return true;
            }

            case "showRewarded": {
                final String adId = args.getString(0);
                final boolean[] rewarded = {false};
                activity.runOnUiThread(() -> Tapsell.showRewardedAd(adId, activity, new AdStateListener.Rewarded() {
                    @Override public void onAdImpression() { /* فقط لاگ سمت تپسل، اقدامی لازم نیست */ }
                    @Override public void onAdClicked() { /* فقط لاگ سمت تپسل، اقدامی لازم نیست */ }
                    @Override
                    public void onRewarded() {
                        rewarded[0] = true;
                    }
                    @Override
                    public void onAdClosed(AdShowCompletionState completionState) {
                        JSONObject result = new JSONObject();
                        try {
                            result.put("rewarded", rewarded[0]);
                            result.put("state", completionState.name());
                        } catch (JSONException ignored) {}
                        callbackContext.success(result);
                    }
                    @Override
                    public void onAdFailed(String message) {
                        callbackContext.error(message == null ? "SHOW_FAILED" : message);
                    }
                }));
                return true;
            }

            case "requestBanner": {
                String zoneId = args.getString(0);
                Tapsell.requestBannerAd(zoneId, BannerSize.BANNER_320_50, new RequestResultListener() {
                    @Override
                    public void onSuccess(String adId) {
                        callbackContext.success(adId);
                    }
                    @Override
                    public void onFailure() {
                        callbackContext.error("NO_FILL");
                    }
                });
                return true;
            }

            case "showBanner": {
                final String adId = args.getString(0);
                activity.runOnUiThread(() -> {
                    if (bannerContainer == null) {
                        bannerContainer = new BannerContainer(activity);
                        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(
                                FrameLayout.LayoutParams.WRAP_CONTENT,
                                FrameLayout.LayoutParams.WRAP_CONTENT
                        );
                        lp.gravity = android.view.Gravity.BOTTOM | android.view.Gravity.CENTER_HORIZONTAL;
                        // به ریشه‌ی محتوای اکتیویتی (روی WebView) اضافه میکنیم
                        ((FrameLayout) activity.getWindow().getDecorView()
                                .findViewById(android.R.id.content)).addView(bannerContainer, lp);
                    }
                    Tapsell.showBannerAd(adId, bannerContainer, activity, new AdStateListener.Banner() {
                        @Override public void onAdImpression() { /* فقط لاگ سمت تپسل، اقدامی لازم نیست */ }
                        @Override public void onAdClicked() { /* فقط لاگ سمت تپسل، اقدامی لازم نیست */ }
                        @Override
                        public void onAdFailed(String message) {
                            callbackContext.error(message == null ? "SHOW_FAILED" : message);
                        }
                    });
                    callbackContext.success();
                });
                return true;
            }

            case "destroyBanner": {
                String adId = args.getString(0);
                Tapsell.destroyBannerAd(adId);
                callbackContext.success();
                return true;
            }

            default:
                return false;
        }
    }
}
