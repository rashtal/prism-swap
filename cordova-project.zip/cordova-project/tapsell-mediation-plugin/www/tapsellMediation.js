var exec = require('cordova/exec');

var TapsellMediationCustom = {

  getInitStatus: function () {
    return new Promise(function (resolve, reject) {
      exec(resolve, reject, 'TapsellMediationCustom', 'getInitStatus', []);
    });
  },

  requestInterstitial: function (zoneId) {
    return new Promise(function (resolve, reject) {
      exec(resolve, reject, 'TapsellMediationCustom', 'requestInterstitial', [zoneId]);
    });
  },

  showInterstitial: function (adId) {
    return new Promise(function (resolve, reject) {
      exec(resolve, reject, 'TapsellMediationCustom', 'showInterstitial', [adId]);
    });
  },

  requestRewarded: function (zoneId) {
    return new Promise(function (resolve, reject) {
      exec(resolve, reject, 'TapsellMediationCustom', 'requestRewarded', [zoneId]);
    });
  },

  showRewarded: function (adId) {
    return new Promise(function (resolve, reject) {
      exec(resolve, reject, 'TapsellMediationCustom', 'showRewarded', [adId]);
    });
  },

  requestBanner: function (zoneId) {
    return new Promise(function (resolve, reject) {
      exec(resolve, reject, 'TapsellMediationCustom', 'requestBanner', [zoneId]);
    });
  },

  showBanner: function (adId) {
    return new Promise(function (resolve, reject) {
      exec(resolve, reject, 'TapsellMediationCustom', 'showBanner', [adId]);
    });
  },

  destroyBanner: function (adId) {
    return new Promise(function (resolve, reject) {
      exec(resolve, reject, 'TapsellMediationCustom', 'destroyBanner', [adId]);
    });
  }

};

module.exports = TapsellMediationCustom;
