package ir.prismswap.tapsellplugin;

import android.app.Activity;
import android.widget.FrameLayout;
import android.content.pm.PackageManager;
import android.content.pm.ApplicationInfo;
import android.os.Bundle;

import org.apache.cordova.CordovaPlugin;
import org.apache.cordova.CallbackContext;
import org.apache.cordova.PluginResult;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import ir.tapsell.mediation.Tapsell;
import ir.tapsell.mediation.ad.request.RequestResultListener;
import ir.tapsell.mediation.ad.request.BannerSize;
import ir.tapsell.mediation.ad.AdStateListener;
import ir.tapsell.mediation.ad.views.banner.BannerContainer;

import java.util.HashMap;
import java.util.Map;
import java.lang.reflect.Proxy;

/**
 * پلاگین سفارشی Prism Swap برای Tapsell Mediation.
 * جایگزین tapsell-v3-cordova-plugin (که طبق اعلام پشتیبانی تپسل دیگه
 * نگهداری نمیشه و به SDK قدیمی ir.tapsell.sdk.* وصل میشه، نه Mediation).
 *
 * مستندات رسمی: https://docs.tapsell.ir/mediation/android/
 */
public class TapsellMediationPlugin extends CordovaPlugin {

    // بنر یه View بومیه، نه چیزی که مثل تبلیغ تمام‌صفحه فقط با adId کار کنه؛
    // پس باید یه BannerContainer رو نگه داریم و به ریشه‌ی صفحه اضافه کنیم.
    private BannerContainer bannerContainer;

    // چون Sam فقط موبایل داره و به adb/logcat دسترسی نداره، وضعیت واقعی
    // init شدن SDK رو اینجا نگه میداریم تا از سمت JS/پنل دیباگ داخل اپ
    // قابل چک کردن باشه — این مهم‌ترین سیگنال تشخیصیه: اگه SDK اصلاً
    // init نشه، هیچ درخواست تبلیغی هیچ‌وقت جواب نمیگیره.
    private static volatile boolean sdkInitCompleted = false;
    private static volatile boolean initListenerRegistered = false;
    private static volatile String initListenerError = null;

    @Override
    protected void pluginInitialize() {
        super.pluginInitialize();
        if (!initListenerRegistered) {
            initListenerRegistered = true;
            try {
                Tapsell.setInitializationListener(() -> {
                    sdkInitCompleted = true;
                });
            } catch (Throwable t) {
                initListenerError = t.getClass().getSimpleName() + ": " + t.getMessage();
            }
        }
    }

    @Override
    public boolean execute(String action, JSONArray args, CallbackContext callbackContext) throws JSONException {
        final Activity activity = cordova.getActivity();

        switch (action) {

            case "getInitStatus": {
                JSONObject status = new JSONObject();
                try {
                    status.put("sdkInitCompleted", sdkInitCompleted);
                    status.put("initListenerError", initListenerError);

                    // این‌جا مستقیم مانیفست نهایی build‌شده رو می‌خونیم تا ببینیم
                    // App ID/manifestPlaceholder واقعاً merge شده یا نه — بدون
                    // نیاز به decompile کردن APK روی کامپیوتر.
                    JSONObject manifestMeta = new JSONObject();
                    try {
                        ApplicationInfo ai = activity.getPackageManager().getApplicationInfo(
                                activity.getPackageName(), PackageManager.GET_META_DATA);
                        Bundle meta = ai.metaData;
                        if (meta != null) {
                            for (String key : meta.keySet()) {
                                if (key.toLowerCase().contains("tapsell")) {
                                    Object v = meta.get(key);
                                    manifestMeta.put(key, String.valueOf(v));
                                }
                            }
                        }
                    } catch (Throwable t) {
                        manifestMeta.put("_error", t.getClass().getSimpleName() + ": " + t.getMessage());
                    }
                    status.put("tapsellManifestMeta", manifestMeta);
                } catch (JSONException ignored) {}
                callbackContext.success(status);
                return true;
            }

            case "requestInterstitial": {
                String zoneId = args.getString(0);
                try {
                    Tapsell.requestInterstitialAd(zoneId, new RequestResultListener() {
                        @Override
                        public void onSuccess(String adId) {
                            callbackContext.success(adId);
                        }
                        @Override
                        public void onFailure(String message) {
                            callbackContext.error(message == null ? "NO_FILL" : message);
                        }
                    });
                } catch (Throwable t) {
                    callbackContext.error("NATIVE_EXCEPTION: " + t.getClass().getSimpleName() + ": " + t.getMessage());
                }
                return true;
            }

            case "showInterstitial": {
                final String adId = args.getString(0);
                activity.runOnUiThread(() -> {
                    // به‌جای implement مستقیم AdStateListener.Interstitial (که نیاز به دونستن
                    // مسیر دقیق کلاس AdShowCompletionState داره و چند بار غلط از آب دراومد)،
                    // از Proxy پویا استفاده میکنیم: متدها رو با اسمشون (String) صدا میزنیم،
                    // نه با نوع کامپایل‌تایم. این‌جوری دیگه فرقی نمیکنه اون enum کجای
                    // SDK باشه یا اسمش دقیقاً چی باشه — با toString() مقدارش رو میگیریم.
                    Object listener = Proxy.newProxyInstance(
                            AdStateListener.Interstitial.class.getClassLoader(),
                            new Class<?>[]{AdStateListener.Interstitial.class},
                            (proxy, method, methodArgs) -> {
                                switch (method.getName()) {
                                    case "onAdClosed": {
                                        String state = (methodArgs != null && methodArgs.length > 0 && methodArgs[0] != null)
                                                ? methodArgs[0].toString() : "UNKNOWN";
                                        callbackContext.success(state);
                                        break;
                                    }
                                    case "onAdFailed": {
                                        String msg = (methodArgs != null && methodArgs.length > 0 && methodArgs[0] != null)
                                                ? methodArgs[0].toString() : "SHOW_FAILED";
                                        callbackContext.error(msg);
                                        break;
                                    }
                                    default:
                                        // onAdImpression / onAdClicked → فقط لاگ سمت تپسل، اقدامی لازم نیست
                                        break;
                                }
                                return null;
                            }
                    );
                    Tapsell.showInterstitialAd(adId, activity, (AdStateListener.Interstitial) listener);
                });
                return true;
            }

            case "requestRewarded": {
                String zoneId = args.getString(0);
                try {
                    Tapsell.requestRewardedAd(zoneId, new RequestResultListener() {
                        @Override
                        public void onSuccess(String adId) {
                            callbackContext.success(adId);
                        }
                        @Override
                        public void onFailure(String message) {
                            callbackContext.error(message == null ? "NO_FILL" : message);
                        }
                    });
                } catch (Throwable t) {
                    callbackContext.error("NATIVE_EXCEPTION: " + t.getClass().getSimpleName() + ": " + t.getMessage());
                }
                return true;
            }

            case "showRewarded": {
                final String adId = args.getString(0);
                final boolean[] rewarded = {false};
                activity.runOnUiThread(() -> {
                    Object listener = Proxy.newProxyInstance(
                            AdStateListener.Rewarded.class.getClassLoader(),
                            new Class<?>[]{AdStateListener.Rewarded.class},
                            (proxy, method, methodArgs) -> {
                                switch (method.getName()) {
                                    case "onRewarded":
                                        rewarded[0] = true;
                                        break;
                                    case "onAdClosed": {
                                        String state = (methodArgs != null && methodArgs.length > 0 && methodArgs[0] != null)
                                                ? methodArgs[0].toString() : "UNKNOWN";
                                        JSONObject result = new JSONObject();
                                        try {
                                            result.put("rewarded", rewarded[0]);
                                            result.put("state", state);
                                        } catch (JSONException ignored) {}
                                        callbackContext.success(result);
                                        break;
                                    }
                                    case "onAdFailed": {
                                        String msg = (methodArgs != null && methodArgs.length > 0 && methodArgs[0] != null)
                                                ? methodArgs[0].toString() : "SHOW_FAILED";
                                        callbackContext.error(msg);
                                        break;
                                    }
                                    default:
                                        // onAdImpression / onAdClicked → فقط لاگ سمت تپسل، اقدامی لازم نیست
                                        break;
                                }
                                return null;
                            }
                    );
                    Tapsell.showRewardedAd(adId, activity, (AdStateListener.Rewarded) listener);
                });
                return true;
            }

            case "requestBanner": {
                String zoneId = args.getString(0);
                Tapsell.requestBannerAd(zoneId, BannerSize.BANNER_320_50, new RequestResultListener() {
                    @Override
                    public void onSuccess(String adId) {
                        callbackContext.success(adId);
                    }
                    @Override
                    public void onFailure(String message) {
                        callbackContext.error(message == null ? "NO_FILL" : message);
                    }
                });
                return true;
            }

            case "showBanner": {
                final String adId = args.getString(0);
                activity.runOnUiThread(() -> {
                    if (bannerContainer == null) {
                        bannerContainer = new BannerContainer(activity);
                        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(
                                FrameLayout.LayoutParams.WRAP_CONTENT,
                                FrameLayout.LayoutParams.WRAP_CONTENT
                        );
                        lp.gravity = android.view.Gravity.BOTTOM | android.view.Gravity.CENTER_HORIZONTAL;
                        // به ریشه‌ی محتوای اکتیویتی (روی WebView) اضافه میکنیم
                        ((FrameLayout) activity.getWindow().getDecorView()
                                .findViewById(android.R.id.content)).addView(bannerContainer, lp);
                    }
                    Tapsell.showBannerAd(adId, bannerContainer, activity, new AdStateListener.Banner() {
                        @Override public void onAdImpression() { /* فقط لاگ سمت تپسل، اقدامی لازم نیست */ }
                        @Override public void onAdClicked() { /* فقط لاگ سمت تپسل، اقدامی لازم نیست */ }
                        @Override
                        public void onAdFailed(String message) {
                            callbackContext.error(message == null ? "SHOW_FAILED" : message);
                        }
                    });
                    callbackContext.success();
                });
                return true;
            }

            case "destroyBanner": {
                String adId = args.getString(0);
                Tapsell.destroyBannerAd(adId);
                callbackContext.success();
                return true;
            }

            default:
                return false;
        }
    }
}
